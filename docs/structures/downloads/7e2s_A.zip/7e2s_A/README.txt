7e2s_A | ATLAS | 233 aa

Open ensemble.pse in PyMOL to rotate, zoom, and toggle the GT_MD and OriDynamic groups.
GT / MD is pink; OriDynamic is blue. Each group contains eight sampled conformations.
The first is a representative; the remaining seven are shown as thin traces.
PDB files contain the aligned display coordinates used in the viewer.
