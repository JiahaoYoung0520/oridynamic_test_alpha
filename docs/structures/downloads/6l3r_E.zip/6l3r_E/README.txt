6l3r_E | ATLAS | 669 aa

Each ensemble contains 40 sampled conformations.
Open ensemble.pse in PyMOL; use its movie play control to cycle through samples.
Drag to rotate, scroll to zoom, and toggle GT_MD / OriDynamic to compare ensembles.
GT / MD is pink; OriDynamic is blue. The first sample is a representative.
PDB files contain the aligned display coordinates. Playback follows sample order, not physical time.
